package com.csv.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.csv.entity.CsvModel;
import com.csv.entity.Fields;
import com.csv.service.CsvService;

@RestController
public class CsvController {

	@Autowired
	private CsvService service;

	@GetMapping(value = "/geturl", produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody List<Fields> getUrls() throws Exception {

		return service.getUrl();
	}
}
