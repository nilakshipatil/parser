package com.csv.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.csv.entity.CsvModel;
import com.csv.entity.Fields;

@Repository
public interface CsvRepository extends JpaRepository<Fields, Integer> {

}
