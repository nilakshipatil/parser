package com.csv.service;

import org.supercsv.cellprocessor.CellProcessorAdaptor;
import org.supercsv.cellprocessor.ift.StringCellProcessor;
import org.supercsv.util.CsvContext;

import com.csv.entity.Progress;

public class ParseProgress extends CellProcessorAdaptor implements StringCellProcessor {

	@Override
	public <Progress> Progress execute(Object value, CsvContext context) {
		// TODO Auto-generated method stub
		
		validateInputNotNull(value, context);
		Progress progress = null;
		 if (value.equals(null)) {
                return next.execute(progress, context);
            }
		 return next.execute(value, context);
	}

}
