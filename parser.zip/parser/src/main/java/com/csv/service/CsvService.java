package com.csv.service;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.dozer.DozerConverter;
import org.dozer.loader.api.BeanMappingBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.supercsv.cellprocessor.CellProcessorAdaptor;
import org.supercsv.cellprocessor.Optional;
import org.supercsv.cellprocessor.ParseInt;
import org.supercsv.cellprocessor.constraint.NotNull;
import org.supercsv.cellprocessor.ift.CellProcessor;
import org.supercsv.cellprocessor.ift.StringCellProcessor;
import org.supercsv.io.CsvBeanReader;
import org.supercsv.io.ICsvBeanReader;
import org.supercsv.io.dozer.CsvDozerBeanReader;
import org.supercsv.io.dozer.ICsvDozerBeanReader;
import org.supercsv.prefs.CsvPreference;
import org.supercsv.util.CsvContext;

import com.csv.entity.Fields;
import com.csv.entity.IssueComment;
import com.csv.entity.Progress;
import com.csv.entity.User;
import com.csv.repo.CsvRepository;

@Service
public class CsvService {
	private final String FILE_PATH = getClass().getClassLoader().getResource("fields.csv").getPath();
	 
	@Autowired
	private CsvRepository dao;

	public List<Fields> getUrl() throws Exception {
		List<Fields> list = new ArrayList<>();
				
		ICsvDozerBeanReader beanReader = null;
		final CsvPreference PREFS = new CsvPreference.Builder(CsvPreference.STANDARD_PREFERENCE).surroundingSpacesNeedQuotes(true).build();

		try {
		   
			 beanReader = new CsvDozerBeanReader(new FileReader(FILE_PATH),PREFS);
			
			 final String[] header = beanReader.getHeader(true);
			 
			 // set up the field mapping, processors and hints dynamically
			 final String[] fieldMapping = new String[header.length];
	         final CellProcessor[] processors = new CellProcessor[header.length];
	         final Class<?>[] hintTypes = new Class<?>[header.length];
	         
	         for (int i = 0; i < header.length; i++)
	         {
	        	 	fieldMapping[i] = header[i];
	        	 	if (header[i].equals("id"))
	                {
	                    processors[i] = new ParseInt();
	                    hintTypes[i] = Integer.class;
	                }
	        	 	if (header[i].equals("aggregatetimeestimate"))
	                {
	                    processors[i] = new NotNull();
	                    hintTypes[i] = String.class;
	                }
	        	 	if (header[i].equals("aggregateprogress"))
	                {
	                    processors[i] = new ParseInt();
	                    hintTypes[i] =  Integer.class;
	                }
	               
	       }
	
	      beanReader.configureBeanMapping(Fields.class, fieldMapping, hintTypes);
	      Fields field;
	      while ((field = beanReader.read(Fields.class,processors)) != null) 
	      {
	    	  System.out.println(String.format("lineNo=%s, rowNo=%s, Field=%s", beanReader.getLineNumber(),
	    			  beanReader.getRowNumber(), field));
	    	  	  list.add(field);
				  dao.save(field);
	       }
	     }
		 finally {
	        if (beanReader != null)
	        {
	            beanReader.close();
	        }
	     }
	 	 return list;
	}
	
}


