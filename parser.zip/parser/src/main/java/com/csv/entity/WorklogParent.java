package com.csv.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="worklog_parent")
public class WorklogParent {
	
	@Id
	@Column(name="id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@Column(name = "total")
	private float total;
	
	@Column(name = "max_results")
	private float maxResults;
	
	@Column(name = "start_at")
	private float startAt;
	
	@OneToMany(fetch = FetchType.LAZY, cascade=CascadeType.ALL)
	@JoinColumn(name = "worklog_parent_id")
	private List<Worklog> worklogs = new ArrayList<Worklog>();

	public float getTotal() {
		return total;
	}

	public void setTotal(float total) {
		this.total = total;
	}

	public float getMaxResults() {
		return maxResults;
	}

	public void setMaxResults(float maxResults) {
		this.maxResults = maxResults;
	}

	public float getStartAt() {
		return startAt;
	}

	public void setStartAt(float startAt) {
		this.startAt = startAt;
	}

	public List<Worklog> getWorklogs() {
		return worklogs;
	}

	public void setWorklogs(List<Worklog> worklogs) {
		this.worklogs = worklogs;
	}

}
