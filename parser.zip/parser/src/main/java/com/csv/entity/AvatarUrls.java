package com.csv.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="avatar_urls")
public class AvatarUrls {
	
	@Id
	@Column(name="id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@Column(name = "48x48")
	private String x48;
	
	@Column(name = "24x24")
	private String x24;
	
	@Column(name = "16x16")
	private String x16;
	
	@Column(name = "32x32")
	private String x32;

	public String get48x48() {
		return x48;
	}

	public void set48x48(String x48) {
		this.x48 = x48;
	}

	public String get24x24() {
		return x24;
	}

	public void set24x24(String x24) {
		this.x24 = x24;
	}

	public String get16x16() {
		return x16;
	}

	public void set16x16(String x16) {
		this.x16 = x16;
	}

	public String get32x32() {
		return x32;
	}

	public void set32x32(String x32) {
		this.x32 = x32;
	}
	
}
