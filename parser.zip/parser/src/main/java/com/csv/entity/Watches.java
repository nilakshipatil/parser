package com.csv.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="watches")
public class Watches {
	
	@Id
	@Column(name="id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@Column(name = "self")
	private String self;
	
	@Column(name = "is_watching")
	private boolean isWatching;
	
	@Column(name = "watch_count")
	private long watchCount;

	public String getSelf() {
		return self;
	}

	public void setSelf(String self) {
		this.self = self;
	}

	public boolean isWatching() {
		return isWatching;
	}

	public void setWatching(boolean isWatching) {
		this.isWatching = isWatching;
	}

	public long getWatchCount() {
		return watchCount;
	}

	public void setWatchCount(long watchCount) {
		this.watchCount = watchCount;
	}
	
}
