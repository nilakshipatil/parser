package com.csv.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="timetracking")
public class Timetracking {
	
	@Id
	@Column(name="id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@Column(name = "original_estimate_seconds")
	private Long originalEstimateSeconds;

	@Column(name = "time_spent_seconds")
	private Long timeSpentSeconds;
	
	@Column(name = "time_spent")
	private String timeSpent;
	
	@Column(name = "remaining_estimate")
	private String remainingEstimate;
	
	@Column(name = "remaining_estimate_seconds")
	private Long remainingEstimateSeconds;
	
	@Column(name = "original_estimate")
	private String originalEstimate;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Long getOriginalEstimateSeconds() {
		return originalEstimateSeconds;
	}

	public void setOriginalEstimateSeconds(Long originalEstimateSeconds) {
		this.originalEstimateSeconds = originalEstimateSeconds;
	}

	public Long getTimeSpentSeconds() {
		return timeSpentSeconds;
	}

	public void setTimeSpentSeconds(Long timeSpentSeconds) {
		this.timeSpentSeconds = timeSpentSeconds;
	}

	public String getTimeSpent() {
		return timeSpent;
	}

	public void setTimeSpent(String timeSpent) {
		this.timeSpent = timeSpent;
	}

	public String getRemainingEstimate() {
		return remainingEstimate;
	}

	public void setRemainingEstimate(String remainingEstimate) {
		this.remainingEstimate = remainingEstimate;
	}

	public Long getRemainingEstimateSeconds() {
		return remainingEstimateSeconds;
	}

	public void setRemainingEstimateSeconds(Long remainingEstimateSeconds) {
		this.remainingEstimateSeconds = remainingEstimateSeconds;
	}

	public String getOriginalEstimate() {
		return originalEstimate;
	}

	public void setOriginalEstimate(String originalEstimate) {
		this.originalEstimate = originalEstimate;
	}
}
