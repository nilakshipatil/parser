package com.csv.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="fields")
public class Fields {
	
	@Id
	@Column(name="id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@OneToOne(cascade=CascadeType.ALL)
	private IssueType issueType;
	
	@OneToOne(cascade=CascadeType.ALL)
	private Parent parent;
	
//	private List<Object> components = new ArrayList<Object>();
	
	@Column(name = "timespent")
	private String timespent = null;
	
	@Column(name = "timeoriginalesimate")
	private String timeoriginalestimate = null;
	
	@Column(name = "description", columnDefinition="TEXT")
	private String description = null;
	
	@OneToOne(cascade=CascadeType.ALL)
	private Project project;
	
//	private List<Object> fixVersions = new ArrayList<Object>();
	
	@Column(name = "aggregatetimespent")
	private String aggregatetimespent = null;
	
	@Column(name = "resolution")
	private String resolution = null;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@OneToOne(cascade=CascadeType.ALL)
	private Timetracking timetracking;
	
	/*@Column(name = "customfield_10005")
	private String customfield_10005 = null;*/
	
//	private List<Object> attachment = new ArrayList<Object>();
	
	@Column(name = "aggregatetimeestimate")
	private String aggregatetimeestimate = null;
	
	@Column(name = "resolutiondate")
	private String resolutiondate = null;
	
	@Column(name = "workratio")
	private float workratio;
	
	@Column(name = "summary")
	private String summary;
	
	@Column(name = "last_viewed")
	private String lastViewed;
	
	@OneToOne(cascade=CascadeType.ALL)
	private Watches watches;
	
	@OneToOne(cascade=CascadeType.ALL)
	private User creator;
	
//	private List<Object> subtasks = new ArrayList<Object>();
	
	@Column(name = "created")
	private String created;
	
	@OneToOne(cascade=CascadeType.ALL)
	private User reporter;
	
	@Column(name = "customfield_10000")
	private String customfield_10000;
	
	@OneToOne(cascade=CascadeType.ALL)
	private Progress aggregateprogress;
	
	@OneToOne(cascade=CascadeType.ALL)
	private Priority priority;
	
	@Column(name = "customfield_10001")
	private String customfield_10001 = null;
	
	@Column(name = "customfield_10100", columnDefinition="TEXT")
	private String customfield_10100;
	
//	private List<Object> labels = new ArrayList<Object>();
	
	@Column(name = "environment")
	private String environment = null;
	
	@Column(name = "timeestimate")
	private String timeestimate = null;
	
	@Column(name = "aggregatetimeoriginalestimate")
	private String aggregatetimeoriginalestimate = null;
	
//	private List<Object> versions = new ArrayList<Object>();
	
	@Column(name = "duedate")
	private String duedate = null;
	
	@OneToOne(cascade=CascadeType.ALL)
	private Progress progress;
	
	@OneToOne(cascade=CascadeType.ALL)
	private IssueComment comment;
	
//	private List<Object> issuelinks = new ArrayList<Object>();
	
	@OneToOne(cascade=CascadeType.ALL)
	private Votes votes;
	
	@OneToOne(cascade=CascadeType.ALL)
	private WorklogParent worklog;
	
	@OneToOne(cascade=CascadeType.ALL)
	private User assignee;
	
	@Column(name = "updated")
	private String updated;
	
	@OneToOne(cascade=CascadeType.ALL)
	private Status status;

	public IssueType getIssueType() {
		return issueType;
	}

	public void setIssueType(IssueType issueType) {
		this.issueType = issueType;
	}

	public Parent getParent() {
		return parent;
	}

	public void setParent(Parent parent) {
		this.parent = parent;
	}

//	public List<Object> getComponents() {
//		return components;
//	}
//
//	public void setComponents(List<Object> components) {
//		this.components = components;
//	}

	public String getTimespent() {
		return timespent;
	}

	public void setTimespent(String timespent) {
		this.timespent = timespent;
	}

	public String getTimeoriginalestimate() {
		return timeoriginalestimate;
	}

	public void setTimeoriginalestimate(String timeoriginalestimate) {
		this.timeoriginalestimate = timeoriginalestimate;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Project getProject() {
		return project;
	}

	public void setProject(Project project) {
		this.project = project;
	}

//	public List<Object> getFixVersions() {
//		return fixVersions;
//	}
//
//	public void setFixVersions(List<Object> fixVersions) {
//		this.fixVersions = fixVersions;
//	}

	public String getAggregatetimespent() {
		return aggregatetimespent;
	}

	public void setAggregatetimespent(String aggregatetimespent) {
		this.aggregatetimespent = aggregatetimespent;
	}

	public String getResolution() {
		return resolution;
	}

	public void setResolution(String resolution) {
		this.resolution = resolution;
	}

	public Timetracking getTimetracking() {
		return timetracking;
	}

	public void setTimetracking(Timetracking timetracking) {
		this.timetracking = timetracking;
	}

	/*public String getCustomfield_10005() {
		return customfield_10005;
	}

	public void setCustomfield_10005(String customfield_10005) {
		this.customfield_10005 = customfield_10005;
	}*/

//	public List<Object> getAttachment() {
//		return attachment;
//	}
//
//	public void setAttachment(List<Object> attachment) {
//		this.attachment = attachment;
//	}

	public String getAggregatetimeestimate() {
		return aggregatetimeestimate;
	}

	public void setAggregatetimeestimate(String aggregatetimeestimate) {
		this.aggregatetimeestimate = aggregatetimeestimate;
	}

	public String getResolutiondate() {
		return resolutiondate;
	}

	public void setResolutiondate(String resolutiondate) {
		this.resolutiondate = resolutiondate;
	}

	public float getWorkratio() {
		return workratio;
	}

	public void setWorkratio(float workratio) {
		this.workratio = workratio;
	}

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	public String getLastViewed() {
		return lastViewed;
	}

	public void setLastViewed(String lastViewed) {
		this.lastViewed = lastViewed;
	}

	public Watches getWatches() {
		return watches;
	}

	public void setWatches(Watches watches) {
		this.watches = watches;
	}

	public User getCreator() {
		return creator;
	}

	public void setCreator(User creator) {
		this.creator = creator;
	}

//	public List<Object> getSubtasks() {
//		return subtasks;
//	}
//
//	public void setSubtasks(List<Object> subtasks) {
//		this.subtasks = subtasks;
//	}

	public String getCreated() {
		return created;
	}

	public void setCreated(String created) {
		this.created = created;
	}

	public User getReporter() {
		return reporter;
	}

	public void setReporter(User reporter) {
		this.reporter = reporter;
	}

	public String getCustomfield_10000() {
		return customfield_10000;
	}

	public void setCustomfield_10000(String customfield_10000) {
		this.customfield_10000 = customfield_10000;
	}

	public Progress getAggregateprogress() {
		return aggregateprogress;
	}

	public void setAggregateprogress(Progress aggregateprogress) {
		this.aggregateprogress = aggregateprogress;
	}

	public Priority getPriority() {
		return priority;
	}

	public void setPriority(Priority priority) {
		this.priority = priority;
	}

	public String getCustomfield_10001() {
		return customfield_10001;
	}

	public void setCustomfield_10001(String customfield_10001) {
		this.customfield_10001 = customfield_10001;
	}

	public String getCustomfield_10100() {
		return customfield_10100;
	}

	public void setCustomfield_10100(String customfield_10100) {
		this.customfield_10100 = customfield_10100;
	}

//	public List<Object> getLabels() {
//		return labels;
//	}
//
//	public void setLabels(List<Object> labels) {
//		this.labels = labels;
//	}

	public String getEnvironment() {
		return environment;
	}

	public void setEnvironment(String environment) {
		this.environment = environment;
	}

	public String getTimeestimate() {
		return timeestimate;
	}

	public void setTimeestimate(String timeestimate) {
		this.timeestimate = timeestimate;
	}

	public String getAggregatetimeoriginalestimate() {
		return aggregatetimeoriginalestimate;
	}

	public void setAggregatetimeoriginalestimate(String aggregatetimeoriginalestimate) {
		this.aggregatetimeoriginalestimate = aggregatetimeoriginalestimate;
	}

//	public List<Object> getVersions() {
//		return versions;
//	}
//
//	public void setVersions(List<Object> versions) {
//		this.versions = versions;
//	}

	public String getDuedate() {
		return duedate;
	}

	public void setDuedate(String duedate) {
		this.duedate = duedate;
	}

	public Progress getProgress() {
		return progress;
	}

	public void setProgress(Progress progress) {
		this.progress = progress;
	}

	public IssueComment getComment() {
		return comment;
	}

	public void setComment(IssueComment comment) {
		this.comment = comment;
	}

//	public List<Object> getIssuelinks() {
//		return issuelinks;
//	}
//
//	public void setIssuelinks(List<Object> issuelinks) {
//		this.issuelinks = issuelinks;
//	}

	public Votes getVotes() {
		return votes;
	}

	public void setVotes(Votes votes) {
		this.votes = votes;
	}

	public WorklogParent getWorklog() {
		return worklog;
	}

	public void setWorklog(WorklogParent worklog) {
		this.worklog = worklog;
	}

	public User getAssignee() {
		return assignee;
	}

	public void setAssignee(User assignee) {
		this.assignee = assignee;
	}

	public String getUpdated() {
		return updated;
	}

	public void setUpdated(String updated) {
		this.updated = updated;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

}
